package com.cts.repository;

import com.cts.entity.User;
import com.cts.exception.UserException;

public interface UserDao {
	
	public boolean saveUser(User user) throws UserException;
	public boolean deleteUser(int userId);
	public boolean updateUser(User user);
	public User getUserDetails(int userId);	
	public User checkUserCredentials(User user);
	public User checkUserNameAndEmail(User user);

}
