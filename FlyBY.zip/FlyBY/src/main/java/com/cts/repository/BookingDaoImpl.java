package com.cts.repository;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.entity.Flight;
import com.cts.entity.Passenger;
import com.cts.modal.FlightSearch;
@Repository

public class BookingDaoImpl implements BookingDao {

	@Autowired
	private SessionFactory sessionfactory;
	
	@Override
	public boolean bookingFlight(Passenger passenger, int flightId, int noOfPassengers) {
		// TODO Auto-generated method stub
		Session session  = sessionfactory.openSession();
		Transaction tx = session.beginTransaction();
		Query flightList=session.createNamedQuery("getFlightDetail");
		flightList.setParameter("fid", flightId);
		Flight bookingTheFlight = (Flight) flightList.getSingleResult();
		bookingTheFlight.setSeatsBooked((bookingTheFlight.getSeatsBooked() + noOfPassengers));
		updateFlight(bookingTheFlight);
		passenger.setFlight(bookingTheFlight);
		session.persist(passenger);
		tx.commit();
		return true;
	}
	@Override
	public boolean saveFlight(Flight flight) {
		// TODO Auto-generated method stub
		System.out.println("MY Flight Info    :::::   "+ flight);
		Session session  = sessionfactory.openSession();
		Transaction tx = session.beginTransaction();
		session.persist(flight);
		tx.commit();
		return false;
	}
	@Override
	public boolean updateFlight(Flight flight) {
		// TODO Auto-generated method stub
		System.out.println("MY flight Info    :::::   "+ flight);
		Session session  = sessionfactory.openSession();
		Transaction tx = session.beginTransaction();
		try {
			session.merge(flight);
			tx.commit();
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return false;
	}
	@Override
	public List<Passenger> bookingHistory(int userId) {
		// TODO Auto-generated method stub
		Session session  = sessionfactory.openSession();
		System.out.println("bookingHIstory userId\t"+userId);
		List<Passenger> passenger = null;
		try {
		Query query=session.createNamedQuery("getPassengerDetail");
		query.setParameter("passengerId", userId);
		 passenger =  query.getResultList();
		}catch(Exception e) {
			System.out.println("No booking history found");
		}
		return passenger;
	}

	@Override
	public List<Flight> searchCorrespondingFlights(FlightSearch searchObject) {
		// TODO Auto-generated method stub
		Session session  = sessionfactory.openSession();
		
		Query query=session.createNamedQuery("searchFlights");
		query.setParameter("source", searchObject.getSource());
		query.setParameter("destination", searchObject.getDestination());
		query.setParameter("dateOfJourney", searchObject.getDateOfJournay());
		List<Flight> flights =  query.getResultList();
		
		
		return flights;
	}
	

}
