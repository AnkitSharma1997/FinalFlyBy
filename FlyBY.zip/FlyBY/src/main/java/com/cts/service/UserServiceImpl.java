package com.cts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.entity.Flight;
import com.cts.entity.User;
import com.cts.exception.UserException;
import com.cts.repository.UserDao;
@Service
public class UserServiceImpl implements UserService {
     @Autowired
     private UserDao dao;
     
	@Override
	public String saveUser(User user){
		System.out.println("userSercieImpl save user method");
		boolean flag = false;
		String message;
		try {
			flag = dao.saveUser(user);
		} catch (UserException e) {
			// TODO Auto-generated catch block
			message = e.getMessage();
			System.out.println(e.getMessage()+"\t userServiceImpl meassage \t"+message);
			if(!flag)
				return message;
		}
		return null;
	}

	@Override
	public boolean deleteUser(int userId) {
		// TODO Auto-generated method stub
		return dao.deleteUser(userId);
	}

	@Override
	public boolean updateUser(User user) {
		// TODO Auto-generated method stub
		return dao.updateUser(user);
	}

	@Override
	public User getUserDetails(int userId) {
		// TODO Auto-generated method stub
		return dao.getUserDetails(userId);
	}

	
	@Override
	public User checkUserCredentials(User user){
		// TODO Auto-generated method stub
		User user_before_validation = dao.checkUserCredentials(user);
		if(user_before_validation != null)
			return user_before_validation;
		return null;
	}

}
