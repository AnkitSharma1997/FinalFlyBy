package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.entity.Flight;
import com.cts.entity.Passenger;
import com.cts.modal.FlightSearch;
import com.cts.repository.BookingDao;

@Service
public class BookingImpl implements Booking {
	@Autowired
	private BookingDao bookingDao;
	@Override
	public boolean bookingFlight(Passenger passenger, int flightId, int noOfPassengers) {
		// TODO Auto-generated method stub
		return bookingDao.bookingFlight(passenger, flightId, noOfPassengers);
	}
	@Override
	public boolean saveFlight(Flight flight) {
		// TODO Auto-generated method stub
		return bookingDao.saveFlight(flight);
	}

	@Override
	public List<Passenger> bookingHistory(int userId) {
		// TODO Auto-generated method stub
		
		return bookingDao.bookingHistory(userId);
	}
	@Override
	public List<Flight> searchCorrespondingFlights(FlightSearch searchObject) {
		// TODO Auto-generated method stub
		return bookingDao.searchCorrespondingFlights(searchObject);
	}
	
	

}
