package com.cts.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="flight")

@NamedQueries(
		{
		@NamedQuery(name="searchFlights",query="from Flight F where F.source =:source and F.destination=:destination and F.dateOfJourney=:dateOfJourney"),
		
		@NamedQuery(name="getFlightDetail", query="from Flight F where F.flightId =:fid")
		}
		
		)
		
public class Flight {
	
	@Id
	@GeneratedValue
	@Column(name="flightId")
	private int flightId;
	@Column(name="flightName")
	private String flightName;
	@Column(name="source")
	private String source;
	@Column(name="destination")
	private String destination;
	@Transient
	private int remaningSeats;
	@Column(name="seatsAvailable")
	private int seatsAvailable;
	@Column(name="seastsBooked")
	private int seatsBooked;
	@Column(name="fare")
	private double fare;
	@Column(name="timeOfArrival")
	private String timeOfArrival;
	@Column(name="timeOfDeparture")
	private String timeOfDeparture;
	@Column(name ="dateOfJourney")
	private String dateOfJourney;
	
	
	public int getFlightId() {
		return flightId;
	}
	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public int getRemaningSeats() {
		return remaningSeats;
	}
	public void setRemaningSeats(int remaningSeats) {
		this.remaningSeats = remaningSeats;
	}
	public int getSeatsAvailable() {
		return seatsAvailable;
	}
	public void setSeatsAvailable(int seatsAvailable) {
		this.seatsAvailable = seatsAvailable;
	}
	public int getSeatsBooked() {
		return seatsBooked;
	}
	public void setSeatsBooked(int seatsBooked) {
		this.seatsBooked = seatsBooked;
	}
	public double getFare() {
		return fare;
	}
	public void setFare(double fare) {
		this.fare = fare;
	}
	public String getTimeOfArrival() {
		return timeOfArrival;
	}
	public void setTimeOfArrival(String timeOfArrival) {
		this.timeOfArrival = timeOfArrival;
	}
	public String getTimeOfDeparture() {
		return timeOfDeparture;
	}
	public void setTimeOfDeparture(String timeOfDeparture) {
		this.timeOfDeparture = timeOfDeparture;
	}
	public String getDateOfJourney() {
		return dateOfJourney;
	}
	public void setDateOfJourney(String dateOfJourney) {
		this.dateOfJourney = dateOfJourney;
	}
	@Override
	public String toString() {
		return "Flight [flightId=" + flightId + ", flightName=" + flightName + ", source=" + source + ", destination="
				+ destination + ", remaningSeats=" + remaningSeats + ", seatsAvailable=" + seatsAvailable
				+ ", seatsBooked=" + seatsBooked + ", fare=" + fare + ", timeOfArrival=" + timeOfArrival
				+ ", timeOfDeparture=" + timeOfDeparture + ", dateOfJourney=" + dateOfJourney + "]";
	}
	
	
}
