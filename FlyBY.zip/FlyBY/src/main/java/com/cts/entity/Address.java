package com.cts.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="address")
public class Address {
	
	@Id
	@GeneratedValue
	@Column(name="addId")
	private int addrsId;
	@Column(name="city")
	private String city;
	
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name="user_Id")
	private User user;
	
	public int getAddrsId() {
		return addrsId;
	}

//	public void setAddrsId(int addrsId) {
//		this.addrsId = addrsId;
//	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	

	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Address(int addrsId, String city, User user) {
		super();
		this.addrsId = addrsId;
		this.city = city;
		this.user = user;
	}

	@Override
	public String toString() {
		return "Address [city=" + city + "]";
	}
	
	
}
